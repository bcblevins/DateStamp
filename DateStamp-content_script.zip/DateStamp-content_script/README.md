## DateStamp

### This is a browser extension that inserts the current time and date at the cursor. 

I am making this as there is a need for this functionality at my current job but the software we use does not include it, and there are no plans for it to be added.

### To be added:
- Insert timestamp at cursor, instead of appending the text field
- Allow keyboard shortcuts
